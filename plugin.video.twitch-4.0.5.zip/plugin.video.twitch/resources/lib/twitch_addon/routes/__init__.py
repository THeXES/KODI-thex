# -*- coding: utf-8 -*-
"""

    Copyright (C) 2012-2018 Twitch-on-Kodi

    This file is part of Twitch-on-Kodi (plugin.video.twitch)

    SPDX-License-Identifier: GPL-3.0-only
    See LICENSES/GPL-3.0-only for more information.
"""

__all__ = ['browse', 'channel_video_categories', 'channel_videos', 'clear_list',
           'clear_search_history', 'clips', 'configure_inputstream_adaptive', 'device_login', 'device_login_private',
           'edit_languages', 'edit_sorting',
           'popular_streams', 'followed', 'following',
           'game_categories', 'game_streams', 'games', 'main',
           'maintain', 'new_search', 'play', 'refresh', 'remove_search_history',
           'reset_cache', 'revoke_token', 'revoke_private_token', 'search', 'search_history', 'search_results',
           'settings', 'streams', 'update_token']
